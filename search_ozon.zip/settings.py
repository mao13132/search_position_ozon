NAME_API_FILE = 'eng-artifact-383013-9394903471e2.json'  # Наименования файла-ключа от API google. Файл поместить в папку google_api_file
# NAME_API_FILE = 'eng-artifact-383013-307a74c20083.json'  # Наименования файла-ключа от API google. Файл поместить в папку google_api_file

ID_SHEET = '1MYDbQ7NDznt-Ha7EGu3-SEptTmUh-vEG36RZWEmUYxs'
# ID_SHEET = '1Emwc-lwopwyBjNmtasvg8RemHmQM4iSKllQoUV9pM20'

BLACK_NAME = []

NAME_SHEET = []  # Здесь можно ввести конкретные имена вкладок. Если список пустой [], то софт получит имена сам

PHONE = '9648325336'  # Без 7 и 8
